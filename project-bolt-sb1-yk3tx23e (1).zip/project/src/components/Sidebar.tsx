import { NavLink, useNavigate } from 'react-router-dom';
import {
  CheckSquare,
  FileText,
  Timer,
  BarChart3,
  LayoutDashboard,
  LogOut,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const navigation = [
  { name: 'Dashboard', to: '/', icon: LayoutDashboard },
  { name: 'Tasks', to: '/tasks', icon: CheckSquare },
  { name: 'Notes', to: '/notes', icon: FileText },
  { name: 'Focus Timer', to: '/focus', icon: Timer },
  { name: 'Statistics', to: '/stats', icon: BarChart3 },
];

export function Sidebar() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <div className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-72 lg:flex-col">
      <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-gradient-to-b from-purple-600 to-purple-700 px-4 pb-4 border-r-4 border-pink-500">
        {/* Logo */}
        <div className="flex h-20 shrink-0 items-center gap-3 px-2">
          <div className="h-12 w-12 bg-pink-500 flex items-center justify-center border-4 border-purple-900 shadow-[4px_4px_0_#ff6b9d]">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
          <div>
            <span className="pixel-font text-lg text-white leading-tight block">Task</span>
            <span className="pixel-font text-lg text-pink-400 leading-tight block">Pixel</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex flex-1 flex-col">
          <ul role="list" className="flex flex-1 flex-col gap-y-2">
            <li>
              <ul role="list" className="space-y-2">
                {navigation.map((item) => (
                  <li key={item.name}>
                    <NavLink
                      to={item.to}
                      className={({ isActive }) =>
                        `group flex gap-x-3 px-4 py-3 text-sm font-bold leading-6 transition-all ${
                          isActive
                            ? 'bg-pink-500 text-white border-4 border-purple-900 shadow-[4px_4px_0_#d94a7a]'
                            : 'text-purple-200 hover:bg-purple-800 hover:text-white border-4 border-transparent'
                        }`
                      }
                    >
                      <item.icon className="h-6 w-6 shrink-0" />
                      <span className="pixel-font text-[10px]">{item.name}</span>
                    </NavLink>
                  </li>
                ))}
              </ul>
            </li>

            {/* User Info & Sign Out */}
            <li className="mt-auto">
              <div className="flex items-center gap-x-3 px-4 py-3 mb-3 bg-purple-800 border-4 border-purple-500">
                <div className="h-10 w-10 bg-gradient-to-br from-pink-400 to-purple-500 flex items-center justify-center border-4 border-purple-900 shadow-[3px_3px_0_#ff6b9d]">
                  <span className="pixel-font text-xs text-white">
                    {user?.email?.charAt(0).toUpperCase()}
                  </span>
                </div>
                <span className="flex-1 text-sm text-purple-200 truncate font-medium">
                  {user?.email?.split('@')[0]}
                </span>
              </div>

              <button
                onClick={handleSignOut}
                className="group flex w-full gap-x-3 px-4 py-3 text-sm font-bold leading-6 text-pink-300 hover:bg-pink-500 hover:text-white border-4 border-pink-600 transition-all"
              >
                <LogOut className="h-6 w-6 shrink-0" />
                <span className="pixel-font text-[10px]">Sign Out</span>
              </button>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
}
