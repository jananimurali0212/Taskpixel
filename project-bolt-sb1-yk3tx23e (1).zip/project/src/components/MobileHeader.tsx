import { useState } from 'react';
import { Sparkles, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export function MobileHeader() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [showMenu, setShowMenu] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
    setShowMenu(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 lg:hidden">
      <div className="bg-purple-700 border-b-4 border-pink-500 px-4 py-2">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          {/* Logo and Name */}
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-pink-500 flex items-center justify-center border-2 border-purple-900" style={{ boxShadow: '2px 2px 0 #a855f7' }}>
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div>
              <span className="pixel-font text-[10px] text-white leading-tight block">Task</span>
              <span className="pixel-font text-[10px] text-pink-400 leading-tight block">Pixel</span>
            </div>
          </div>

          {/* Made in Bolt Badge */}
          <div className="flex items-center gap-2">
            <a
              href="https://bolt.new"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-2 py-1 bg-purple-900 border-2 border-pink-500 hover:bg-purple-800 transition-colors"
            >
              <span className="text-[8px] pixel-font text-pink-400">MADE WITH</span>
              <span className="text-[10px] font-bold text-white">Bolt</span>
            </a>

            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-1.5 text-white bg-purple-900 border-2 border-purple-500"
            >
              {showMenu ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Dropdown Menu */}
      {showMenu && (
        <div className="bg-purple-800 border-b-4 border-pink-500 px-4 py-3">
          <div className="max-w-lg mx-auto">
            <div className="flex items-center gap-3 mb-4 p-3 bg-purple-900 border-2 border-purple-600">
              <div className="h-10 w-10 bg-gradient-to-br from-pink-400 to-purple-500 flex items-center justify-center border-2 border-purple-900">
                <span className="pixel-font text-xs text-white">
                  {user?.email?.charAt(0).toUpperCase()}
                </span>
              </div>
              <span className="text-sm text-white font-medium truncate">
                {user?.email?.split('@')[0]}
              </span>
            </div>
            <button
              onClick={handleSignOut}
              className="w-full flex items-center gap-2 px-4 py-3 bg-pink-500 text-white font-bold border-2 border-pink-700"
            >
              <LogOut className="h-5 w-5" />
              <span className="pixel-font text-[10px]">SIGN OUT</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
