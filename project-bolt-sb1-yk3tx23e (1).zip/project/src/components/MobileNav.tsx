import { NavLink } from 'react-router-dom';
import { CheckSquare, FileText, Timer, BarChart3, LayoutDashboard } from 'lucide-react';

const navItems = [
  { name: 'Home', to: '/', icon: LayoutDashboard },
  { name: 'Tasks', to: '/tasks', icon: CheckSquare },
  { name: 'Timer', to: '/focus', icon: Timer },
  { name: 'Notes', to: '/notes', icon: FileText },
  { name: 'Stats', to: '/stats', icon: BarChart3 },
];

export function MobileNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-purple-700 border-t-4 border-pink-500 lg:hidden safe-area-bottom">
      <div className="flex items-center justify-around h-14 max-w-lg mx-auto px-1">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.to}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 h-full py-1 px-0.5 transition-colors min-w-0 ${
                isActive
                  ? 'text-white bg-pink-500'
                  : 'text-purple-300 hover:text-white active:bg-purple-600'
              }`
            }
          >
            <item.icon className="h-5 w-5 flex-shrink-0" />
            <span className="text-[8px] mt-0.5 pixel-font leading-tight truncate w-full text-center">{item.name}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
