import { useState, useEffect } from 'react';
import { Plus, Search, Pin, Trash2, Edit3, X, FileText } from 'lucide-react';
import { supabase, Note } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

const colorOptions = ['blue', 'green', 'yellow', 'red', 'purple', 'gray'] as const;

const noteColors: Record<string, string> = {
  blue: 'bg-blue-100 border-2 border-blue-400',
  green: 'bg-green-100 border-2 border-green-400',
  yellow: 'bg-yellow-100 border-2 border-yellow-400',
  red: 'bg-rose-100 border-2 border-rose-400',
  purple: 'bg-purple-100 border-2 border-purple-400',
  gray: 'bg-gray-100 border-2 border-gray-400',
};

const colorPickers: Record<string, string> = {
  blue: 'bg-blue-500 border-4 border-blue-700',
  green: 'bg-green-500 border-4 border-green-700',
  yellow: 'bg-yellow-500 border-4 border-yellow-700',
  red: 'bg-rose-500 border-4 border-rose-700',
  purple: 'bg-purple-500 border-4 border-purple-700',
  gray: 'bg-gray-500 border-4 border-gray-700',
};

export function Notes() {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    color: 'blue' as Note['color'],
    pinned: false,
  });

  useEffect(() => {
    if (user) {
      fetchNotes();
    }
  }, [user]);

  const fetchNotes = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .order('pinned', { ascending: false })
      .order('updated_at', { ascending: false });

    if (!error && data) {
      setNotes(data);
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (editingNote) {
      const { error } = await supabase
        .from('notes')
        .update({
          title: formData.title,
          content: formData.content,
          color: formData.color,
          pinned: formData.pinned,
          updated_at: new Date().toISOString(),
        })
        .eq('id', editingNote.id);

      if (!error) {
        fetchNotes();
        closeModal();
      }
    } else {
      const { error } = await supabase.from('notes').insert({
        user_id: user!.id,
        title: formData.title,
        content: formData.content,
        color: formData.color,
        pinned: formData.pinned,
      });

      if (!error) {
        fetchNotes();
        closeModal();
      }
    }
  };

  const togglePin = async (note: Note) => {
    const { error } = await supabase
      .from('notes')
      .update({
        pinned: !note.pinned,
        updated_at: new Date().toISOString(),
      })
      .eq('id', note.id);

    if (!error) {
      fetchNotes();
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('notes').delete().eq('id', id);
    if (!error) {
      fetchNotes();
    }
  };

  const openEditModal = (note: Note) => {
    setEditingNote(note);
    setFormData({
      title: note.title,
      content: note.content || '',
      color: note.color,
      pinned: note.pinned,
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingNote(null);
    setFormData({
      title: '',
      content: '',
      color: 'blue',
      pinned: false,
    });
  };

  const filteredNotes = notes.filter(
    (note) =>
      note.title.toLowerCase().includes(search.toLowerCase()) ||
      note.content?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="h-12 w-12 bg-pink-500 animate-pulse border-4 border-purple-600" style={{ boxShadow: '4px 4px 0 #a855f7' }}></div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-lg mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h1 className="pixel-font text-lg text-purple-700">Notes</h1>
        <button
          onClick={() => setShowModal(true)}
          className="h-10 w-10 bg-pink-500 flex items-center justify-center border-4 border-pink-700 text-white"
          style={{ boxShadow: '4px 4px 0 #d94a7a' }}
        >
          <Plus className="h-5 w-5" />
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-purple-400" />
        <input
          type="text"
          placeholder="Search notes..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2.5 bg-white pixel-input text-sm"
        />
      </div>

      {/* Notes List */}
      {filteredNotes.length === 0 ? (
        <div className="bg-white p-8 border-4 border-purple-500 text-center" style={{ boxShadow: '6px 6px 0 #ff6b9d' }}>
          <FileText className="h-12 w-12 text-purple-300 mx-auto mb-3" />
          <p className="pixel-font text-[10px] text-purple-500">No notes yet!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredNotes.map((note) => (
            <div
              key={note.id}
              className={`relative p-3 ${noteColors[note.color]}`}
              style={{ boxShadow: '4px 4px 0 #a855f7' }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0 pr-2">
                  <div className="flex items-center gap-2 mb-1">
                    {note.pinned && <Pin className="h-3 w-3 text-pink-500" />}
                    <h3 className="font-bold text-sm text-purple-800 truncate">{note.title}</h3>
                  </div>
                  {note.content && (
                    <p className="text-xs text-purple-600 line-clamp-3">{note.content}</p>
                  )}
                  <p className="text-[10px] text-purple-400 mt-2 font-mono">
                    {new Date(note.updated_at).toLocaleDateString()}
                  </p>
                </div>

                <div className="flex gap-1 flex-shrink-0">
                  <button
                    onClick={() => togglePin(note)}
                    className={`p-2 bg-white border-2 border-purple-200 ${note.pinned ? 'text-pink-500 border-pink-400' : 'text-purple-400'}`}
                  >
                    <Pin className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => openEditModal(note)}
                    className="p-2 bg-white border-2 border-purple-200 text-purple-400"
                  >
                    <Edit3 className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(note.id)}
                    className="p-2 bg-white border-2 border-red-200 text-red-500"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white w-full max-w-lg p-5 border-t-4 border-purple-500 rounded-t-2xl">
            <div className="w-12 h-1 bg-purple-300 rounded-full mx-auto mb-4"></div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="pixel-font text-sm text-purple-700">
                {editingNote ? 'Edit Note' : 'New Note'}
              </h2>
              <button
                onClick={closeModal}
                className="p-1.5 bg-gray-100 border-2 border-gray-300"
              >
                <X className="h-4 w-4 text-gray-600" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-purple-600 mb-1 pixel-font">TITLE</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2.5 pixel-input text-sm"
                  placeholder="Note title..."
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-purple-600 mb-1 pixel-font">CONTENT</label>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={4}
                  className="w-full px-3 py-2.5 pixel-input text-sm resize-none"
                  placeholder="Write your note..."
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-purple-600 mb-2 pixel-font">COLOR</label>
                <div className="flex gap-2">
                  {colorOptions.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setFormData({ ...formData, color })}
                      className={`h-8 w-8 ${colorPickers[color]} ${
                        formData.color === color ? 'ring-2 ring-offset-2 ring-pink-400' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 bg-purple-50 border-2 border-purple-200">
                <input
                  type="checkbox"
                  id="pinned-mobile"
                  checked={formData.pinned}
                  onChange={(e) => setFormData({ ...formData, pinned: e.target.checked })}
                  className="h-5 w-5 border-4 border-purple-400 accent-pink-500"
                />
                <label htmlFor="pinned-mobile" className="text-sm font-bold text-purple-700">
                  Pin this note
                </label>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={closeModal}
                  className="flex-1 px-4 py-3 bg-gray-200 text-purple-700 font-bold border-4 border-gray-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-pink-500 text-white font-bold border-4 border-pink-700"
                >
                  {editingNote ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
