import { useState, useEffect } from 'react';
import { Plus, Search, Check, Trash2, Edit3, Calendar, Tag, AlertCircle } from 'lucide-react';
import { supabase, Task } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

const categories = ['work', 'personal', 'health', 'learning'] as const;
const priorities = ['low', 'medium', 'high', 'urgent'] as const;
const statuses = ['pending', 'in-progress', 'completed', 'cancelled'] as const;

const categoryColors: Record<string, string> = {
  work: 'bg-blue-400 border-blue-600',
  personal: 'bg-pink-400 border-pink-600',
  health: 'bg-green-400 border-green-600',
  learning: 'bg-yellow-400 border-yellow-600',
};

const priorityColors: Record<string, string> = {
  low: 'bg-gray-300 border-gray-500',
  medium: 'bg-yellow-400 border-yellow-600',
  high: 'bg-orange-400 border-orange-600',
  urgent: 'bg-red-500 border-red-700',
};

export function Tasks() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'personal' as Task['category'],
    priority: 'medium' as Task['priority'],
    status: 'pending' as Task['status'],
    due_date: '',
  });

  useEffect(() => {
    if (user) {
      fetchTasks();
    }
  }, [user]);

  const fetchTasks = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setTasks(data);
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (editingTask) {
      const { error } = await supabase
        .from('tasks')
        .update({
          title: formData.title,
          description: formData.description,
          category: formData.category,
          priority: formData.priority,
          status: formData.status,
          due_date: formData.due_date || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', editingTask.id);

      if (!error) {
        fetchTasks();
        closeModal();
      }
    } else {
      const { error } = await supabase.from('tasks').insert({
        user_id: user!.id,
        title: formData.title,
        description: formData.description,
        category: formData.category,
        priority: formData.priority,
        status: formData.status,
        due_date: formData.due_date || null,
      });

      if (!error) {
        fetchTasks();
        closeModal();
      }
    }
  };

  const toggleComplete = async (task: Task) => {
    const { error } = await supabase
      .from('tasks')
      .update({
        completed: !task.completed,
        completed_at: !task.completed ? new Date().toISOString() : null,
        status: !task.completed ? 'completed' : 'pending',
        updated_at: new Date().toISOString(),
      })
      .eq('id', task.id);

    if (!error) {
      fetchTasks();
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('tasks').delete().eq('id', id);
    if (!error) {
      fetchTasks();
    }
  };

  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setFormData({
      title: task.title,
      description: task.description || '',
      category: task.category,
      priority: task.priority,
      status: task.status,
      due_date: task.due_date || '',
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingTask(null);
    setFormData({
      title: '',
      description: '',
      category: 'personal',
      priority: 'medium',
      status: 'pending',
      due_date: '',
    });
  };

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(search.toLowerCase()) ||
      task.description?.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = !filterCategory || task.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="h-12 w-12 bg-pink-500 animate-pulse border-4 border-purple-600" style={{ boxShadow: '4px 4px 0 #a855f7' }}></div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-lg mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h1 className="pixel-font text-lg text-purple-700">Tasks</h1>
        <button
          onClick={() => setShowModal(true)}
          className="h-10 w-10 bg-pink-500 flex items-center justify-center border-4 border-pink-700 text-white"
          style={{ boxShadow: '4px 4px 0 #d94a7a' }}
        >
          <Plus className="h-5 w-5" />
        </button>
      </div>

      {/* Search and Filter */}
      <div className="bg-white p-3 mb-4 border-4 border-purple-500" style={{ boxShadow: '4px 4px 0 #ff6b9d' }}>
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-purple-400" />
          <input
            type="text"
            placeholder="Search tasks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 pixel-input text-sm"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setFilterCategory(null)}
            className={`px-3 py-1.5 text-xs font-bold whitespace-nowrap border-2 ${
              !filterCategory ? 'bg-pink-500 text-white border-pink-700' : 'bg-purple-100 text-purple-700 border-purple-300'
            }`}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1.5 text-xs font-bold whitespace-nowrap border-2 ${
                filterCategory === cat ? 'bg-pink-500 text-white border-pink-700' : 'bg-purple-100 text-purple-700 border-purple-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Tasks List */}
      <div className="space-y-3">
        {filteredTasks.length === 0 ? (
          <div className="bg-white p-8 border-4 border-purple-500 text-center" style={{ boxShadow: '6px 6px 0 #ff6b9d' }}>
            <Check className="h-12 w-12 text-purple-300 mx-auto mb-3" />
            <p className="pixel-font text-[10px] text-purple-500">No tasks found!</p>
          </div>
        ) : (
          filteredTasks.map((task) => (
            <div
              key={task.id}
              className="bg-white p-3 border-4 border-purple-500"
              style={{ boxShadow: '4px 4px 0 #ff6b9d' }}
            >
              <div className="flex items-start gap-3">
                <button
                  onClick={() => toggleComplete(task)}
                  className={`mt-0.5 h-6 w-6 border-4 flex items-center justify-center flex-shrink-0 ${
                    task.completed
                      ? 'bg-green-500 border-green-700'
                      : 'bg-white border-purple-400'
                  }`}
                >
                  {task.completed && <Check className="h-4 w-4 text-white" />}
                </button>

                <div className="flex-1 min-w-0">
                  <h3 className={`font-bold text-sm text-purple-800 ${task.completed ? 'line-through text-purple-400' : ''}`}>
                    {task.title}
                  </h3>
                  {task.description && (
                    <p className="text-xs text-purple-500 mt-0.5 line-clamp-2">{task.description}</p>
                  )}
                  <div className="flex flex-wrap items-center gap-1.5 mt-2">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold text-white ${categoryColors[task.category]}`}>
                      <Tag className="h-3 w-3" />
                      {task.category}
                    </span>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold text-white ${priorityColors[task.priority]}`}>
                      <AlertCircle className="h-3 w-3" />
                      {task.priority}
                    </span>
                    {task.due_date && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold text-purple-700 bg-purple-100 border border-purple-300">
                        <Calendar className="h-3 w-3" />
                        {new Date(task.due_date).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex gap-1">
                  <button
                    onClick={() => openEditModal(task)}
                    className="p-2 bg-purple-100 border-2 border-purple-300"
                  >
                    <Edit3 className="h-4 w-4 text-purple-600" />
                  </button>
                  <button
                    onClick={() => handleDelete(task.id)}
                    className="p-2 bg-red-100 border-2 border-red-300"
                  >
                    <Trash2 className="h-4 w-4 text-red-600" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white w-full max-w-lg p-5 border-t-4 border-purple-500 rounded-t-2xl">
            <div className="w-12 h-1 bg-purple-300 rounded-full mx-auto mb-4"></div>
            <h2 className="pixel-font text-sm text-purple-700 mb-4">
              {editingTask ? 'Edit Task' : 'New Task'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-purple-600 mb-1 pixel-font">TITLE</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2.5 pixel-input text-sm"
                  placeholder="Enter task..."
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-purple-600 mb-1 pixel-font">DESCRIPTION</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2.5 pixel-input text-sm resize-none"
                  placeholder="Details..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-purple-600 mb-1 pixel-font">CATEGORY</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as Task['category'] })}
                    className="w-full px-3 py-2.5 pixel-input text-sm font-bold"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>{cat.toUpperCase()}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-purple-600 mb-1 pixel-font">PRIORITY</label>
                  <select
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value as Task['priority'] })}
                    className="w-full px-3 py-2.5 pixel-input text-sm font-bold"
                  >
                    {priorities.map((pri) => (
                      <option key={pri} value={pri}>{pri.toUpperCase()}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-purple-600 mb-1 pixel-font">DUE DATE</label>
                <input
                  type="date"
                  value={formData.due_date}
                  onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                  className="w-full px-3 py-2.5 pixel-input text-sm"
                />
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={closeModal}
                  className="flex-1 px-4 py-3 bg-gray-200 text-purple-700 font-bold border-4 border-gray-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-pink-500 text-white font-bold border-4 border-pink-700"
                >
                  {editingTask ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
