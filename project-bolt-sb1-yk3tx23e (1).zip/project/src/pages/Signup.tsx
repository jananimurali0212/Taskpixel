import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Sparkles, Loader2, CheckCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    const { error } = await signUp(email, password);

    if (error) {
      setError(error.message);
      setLoading(false);
    } else {
      setSuccess(true);
      setTimeout(() => navigate('/login'), 2000);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'linear-gradient(135deg, #fef3e2 0%, #fff8f0 50%, #ffe4f0 100%)' }}>
        <div className="w-full max-w-sm text-center">
          <div className="h-16 w-16 mx-auto mb-4 bg-green-500 flex items-center justify-center border-4 border-green-700" style={{ boxShadow: '4px 4px 0 #16a34a' }}>
            <CheckCircle className="h-8 w-8 text-white" />
          </div>
          <h2 className="pixel-font text-base text-purple-700 mb-2">Success!</h2>
          <p className="text-purple-500 font-medium">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(135deg, #fef3e2 0%, #fff8f0 50%, #ffe4f0 100%)' }}>
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="h-16 w-16 bg-pink-500 flex items-center justify-center border-4 border-purple-700" style={{ boxShadow: '6px 6px 0 #a855f7' }}>
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <div className="text-left">
              <span className="pixel-font text-xl text-purple-700 block leading-tight">Task</span>
              <span className="pixel-font text-xl text-pink-500 block leading-tight">Pixel</span>
            </div>
          </div>

          <h1 className="pixel-font text-base text-purple-700 text-center mb-2">Create Account</h1>
          <p className="text-purple-500 font-medium text-center mb-6">Start your journey</p>

          {error && (
            <div className="mb-4 p-3 bg-red-100 border-4 border-red-400 text-red-700 text-sm font-bold text-center">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block pixel-font text-[10px] text-purple-600 mb-1.5">EMAIL</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-white pixel-input"
                placeholder="you@example.com"
                autoCapitalize="none"
              />
            </div>

            <div>
              <label className="block pixel-font text-[10px] text-purple-600 mb-1.5">PASSWORD</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 bg-white pixel-input"
                placeholder="Create password"
              />
            </div>

            <div>
              <label className="block pixel-font text-[10px] text-purple-600 mb-1.5">CONFIRM</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-3 bg-white pixel-input"
                placeholder="Confirm password"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-pink-500 text-white pixel-font text-xs border-4 border-pink-700 active:translate-y-1 transition-transform flex items-center justify-center gap-2"
              style={{ boxShadow: '4px 4px 0 #d94a7a' }}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  LOADING...
                </>
              ) : (
                'CREATE ACCOUNT'
              )}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-purple-600 font-medium">
            Already playing?{' '}
            <Link to="/login" className="text-pink-500 font-bold">
              Sign In
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
