import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckSquare, FileText, Timer, TrendingUp, Clock, AlertCircle, Sparkles } from 'lucide-react';
import { supabase, Task, Note, PomodoroSession } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export function Dashboard() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [recentSessions, setRecentSessions] = useState<PomodoroSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    setLoading(true);
    const [tasksRes, notesRes, sessionsRes] = await Promise.all([
      supabase.from('tasks').select('*').order('created_at', { ascending: false }).limit(5),
      supabase.from('notes').select('*').order('updated_at', { ascending: false }).limit(3),
      supabase.from('pomodoro_sessions').select('*').order('created_at', { ascending: false }).limit(7),
    ]);

    if (tasksRes.data) setTasks(tasksRes.data);
    if (notesRes.data) setNotes(notesRes.data);
    if (sessionsRes.data) setRecentSessions(sessionsRes.data);
    setLoading(false);
  };

  const pendingTasks = tasks.filter((t) => !t.completed);
  const completedToday = tasks.filter(
    (t) => t.completed && t.completed_at && new Date(t.completed_at).toDateString() === new Date().toDateString()
  ).length;

  const totalFocusMinutes = recentSessions
    .filter((s) => s.completed_at)
    .reduce((acc, s) => acc + s.duration_minutes, 0);

  const overdueTasks = tasks.filter(
    (t) => !t.completed && t.due_date && new Date(t.due_date) < new Date()
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="relative">
          <div className="h-12 w-12 bg-pink-500 animate-pulse border-4 border-purple-600" style={{ boxShadow: '4px 4px 0 #a855f7' }}></div>
          <Sparkles className="absolute -top-2 -right-2 h-6 w-6 text-pink-400 animate-bounce" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-lg mx-auto">
      {/* Greeting */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 bg-pink-500 flex items-center justify-center border-4 border-purple-700" style={{ boxShadow: '4px 4px 0 #a855f7' }}>
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="pixel-font text-xs text-purple-700">Good {getTimeOfDay()}!</p>
            <p className="text-sm text-purple-500 font-medium">{user?.email?.split('@')[0]}</p>
          </div>
        </div>
      </div>

      {/* Stats Grid - 2x2 on mobile */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-white p-4 border-4 border-purple-500" style={{ boxShadow: '6px 6px 0 #ff6b9d' }}>
          <div className="flex items-center justify-between mb-2">
            <div className="h-8 w-8 bg-amber-400 flex items-center justify-center border-2 border-amber-600">
              <CheckSquare className="h-4 w-4 text-white" />
            </div>
            {overdueTasks.length > 0 && (
              <div className="text-red-500">
                <AlertCircle className="h-4 w-4" />
              </div>
            )}
          </div>
          <p className="pixel-font text-[10px] text-purple-500 mb-1">Pending</p>
          <p className="pixel-font text-xl text-purple-700">{pendingTasks.length}</p>
        </div>

        <div className="bg-white p-4 border-4 border-purple-500" style={{ boxShadow: '6px 6px 0 #ff6b9d' }}>
          <div className="h-8 w-8 bg-green-400 flex items-center justify-center border-2 border-green-600 mb-2">
            <TrendingUp className="h-4 w-4 text-white" />
          </div>
          <p className="pixel-font text-[10px] text-purple-500 mb-1">Done Today</p>
          <p className="pixel-font text-xl text-purple-700">{completedToday}</p>
        </div>

        <div className="bg-white p-4 border-4 border-purple-500" style={{ boxShadow: '6px 6px 0 #ff6b9d' }}>
          <div className="h-8 w-8 bg-cyan-400 flex items-center justify-center border-2 border-cyan-600 mb-2">
            <Clock className="h-4 w-4 text-white" />
          </div>
          <p className="pixel-font text-[10px] text-purple-500 mb-1">Focus</p>
          <p className="pixel-font text-xl text-purple-700">{totalFocusMinutes}m</p>
        </div>

        <div className="bg-white p-4 border-4 border-purple-500" style={{ boxShadow: '6px 6px 0 #ff6b9d' }}>
          <div className="h-8 w-8 bg-blue-400 flex items-center justify-center border-2 border-blue-600 mb-2">
            <FileText className="h-4 w-4 text-white" />
          </div>
          <p className="pixel-font text-[10px] text-purple-500 mb-1">Notes</p>
          <p className="pixel-font text-xl text-purple-700">{notes.length}</p>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mb-6">
        <Link
          to="/focus"
          className="block bg-gradient-to-r from-pink-500 to-purple-600 p-4 border-4 border-purple-400"
          style={{ boxShadow: '6px 6px 0 #ff6b9d' }}
        >
          <div className="flex items-center justify-center gap-3">
            <Timer className="h-6 w-6 text-white" />
            <div>
              <p className="pixel-font text-xs text-white">Start Focus</p>
              <p className="text-[10px] text-pink-200">25 min session</p>
            </div>
          </div>
        </Link>
      </div>

      {/* Recent Tasks */}
      <div className="bg-white p-4 border-4 border-purple-500" style={{ boxShadow: '6px 6px 0 #ff6b9d' }}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="pixel-font text-xs text-purple-700">Recent Tasks</h2>
          <Link to="/tasks" className="pixel-font text-[8px] text-pink-500">
            View All
          </Link>
        </div>
        <div className="space-y-2">
          {pendingTasks.length === 0 ? (
            <div className="text-center py-6">
              <p className="pixel-font text-[10px] text-purple-400">All quests complete!</p>
            </div>
          ) : (
            pendingTasks.slice(0, 3).map((task) => (
              <div
                key={task.id}
                className="flex items-center gap-3 p-2 bg-purple-50 border-2 border-purple-200"
              >
                <div
                  className={`h-3 w-3 border-4 ${
                    task.priority === 'urgent'
                      ? 'bg-red-500 border-red-700'
                      : task.priority === 'high'
                      ? 'bg-orange-500 border-orange-700'
                      : task.priority === 'medium'
                      ? 'bg-yellow-500 border-yellow-700'
                      : 'bg-gray-400 border-gray-600'
                  }`}
                />
                <span className="flex-1 text-sm text-purple-700 font-medium truncate">{task.title}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function getTimeOfDay() {
  const hour = new Date().getHours();
  if (hour < 12) return 'MORNING';
  if (hour < 17) return 'AFTERNOON';
  return 'EVENING';
}
