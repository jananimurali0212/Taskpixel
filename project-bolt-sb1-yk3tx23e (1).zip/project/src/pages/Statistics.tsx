import { useState, useEffect } from 'react';
import { BarChart3, Clock, CheckCircle, TrendingUp, Calendar, Sparkles } from 'lucide-react';
import { supabase, Task, PomodoroSession } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export function Statistics() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [sessions, setSessions] = useState<PomodoroSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'all'>('week');

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user, timeRange]);

  const fetchData = async () => {
    setLoading(true);
    const startDate = getStartDate();

    const [tasksRes, sessionsRes] = await Promise.all([
      supabase.from('tasks').select('*').gte('created_at', startDate.toISOString()),
      supabase.from('pomodoro_sessions').select('*').gte('created_at', startDate.toISOString()),
    ]);

    if (tasksRes.data) setTasks(tasksRes.data);
    if (sessionsRes.data) setSessions(sessionsRes.data);
    setLoading(false);
  };

  const getStartDate = () => {
    const now = new Date();
    if (timeRange === 'week') {
      now.setDate(now.getDate() - 7);
    } else if (timeRange === 'month') {
      now.setMonth(now.getMonth() - 1);
    } else {
      now.setFullYear(now.getFullYear() - 10);
    }
    return now;
  };

  const completedTasks = tasks.filter((t) => t.completed);
  const pendingTasks = tasks.filter((t) => !t.completed);
  const completedSessions = sessions.filter((s) => s.completed_at);
  const totalFocusMinutes = completedSessions.reduce((acc, s) => acc + s.duration_minutes, 0);
  const totalFocusHours = (totalFocusMinutes / 60).toFixed(1);
  const completionRate = tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0;

  const categories: Task['category'][] = ['work', 'personal', 'health', 'learning'];

  const tasksByCategory = categories.map((cat) => ({
    category: cat,
    count: tasks.filter((t) => t.category === cat).length,
    completed: tasks.filter((t) => t.category === cat && t.completed).length,
  }));

  const dailyFocusData = getDailyFocusData();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="h-12 w-12 bg-pink-500 animate-pulse border-4 border-purple-600" style={{ boxShadow: '4px 4px 0 #a855f7' }}></div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-lg mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 bg-pink-500 flex items-center justify-center border-4 border-purple-700" style={{ boxShadow: '4px 4px 0 #a855f7' }}>
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <h1 className="pixel-font text-base text-purple-700">Stats</h1>
        </div>
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value as 'week' | 'month' | 'all')}
          className="px-3 py-2 bg-white pixel-input text-sm font-bold text-purple-700"
        >
          <option value="week">7 Days</option>
          <option value="month">30 Days</option>
          <option value="all">All</option>
        </select>
      </div>

      {/* Overview Cards - 2x2 Grid */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-white p-3 border-4 border-purple-500" style={{ boxShadow: '4px 4px 0 #ff6b9d' }}>
          <div className="h-8 w-8 bg-green-400 flex items-center justify-center border-2 border-green-600 mb-2">
            <CheckCircle className="h-4 w-4 text-white" />
          </div>
          <p className="pixel-font text-[10px] text-purple-500 mb-1">Completion</p>
          <p className="pixel-font text-xl text-purple-700 mb-0.5">{completionRate}%</p>
          <p className="text-[10px] text-purple-400">{completedTasks.length}/{tasks.length}</p>
        </div>

        <div className="bg-white p-3 border-4 border-purple-500" style={{ boxShadow: '4px 4px 0 #ff6b9d' }}>
          <div className="h-8 w-8 bg-cyan-400 flex items-center justify-center border-2 border-cyan-600 mb-2">
            <Clock className="h-4 w-4 text-white" />
          </div>
          <p className="pixel-font text-[10px] text-purple-500 mb-1">Focus</p>
          <p className="pixel-font text-xl text-purple-700 mb-0.5">{totalFocusHours}h</p>
          <p className="text-[10px] text-purple-400">{completedSessions.length} sessions</p>
        </div>

        <div className="bg-white p-3 border-4 border-purple-500" style={{ boxShadow: '4px 4px 0 #ff6b9d' }}>
          <div className="h-8 w-8 bg-blue-400 flex items-center justify-center border-2 border-blue-600 mb-2">
            <TrendingUp className="h-4 w-4 text-white" />
          </div>
          <p className="pixel-font text-[10px] text-purple-500 mb-1">Created</p>
          <p className="pixel-font text-xl text-purple-700 mb-0.5">{tasks.length}</p>
          <p className="text-[10px] text-purple-400">total tasks</p>
        </div>

        <div className="bg-white p-3 border-4 border-purple-500" style={{ boxShadow: '4px 4px 0 #ff6b9d' }}>
          <div className="h-8 w-8 bg-amber-400 flex items-center justify-center border-2 border-amber-600 mb-2">
            <BarChart3 className="h-4 w-4 text-white" />
          </div>
          <p className="pixel-font text-[10px] text-purple-500 mb-1">Pending</p>
          <p className="pixel-font text-xl text-purple-700 mb-0.5">{pendingTasks.length}</p>
          <p className="text-[10px] text-purple-400">remaining</p>
        </div>
      </div>

      {/* Tasks by Category */}
      <div className="bg-white p-4 border-4 border-purple-500 mb-4" style={{ boxShadow: '4px 4px 0 #ff6b9d' }}>
        <h2 className="pixel-font text-xs text-purple-700 mb-4">By Category</h2>
        <div className="space-y-3">
          {tasksByCategory.map((item) => {
            const percentage = tasks.length > 0 ? (item.count / tasks.length) * 100 : 0;
            return (
              <div key={item.category}>
                <div className="flex items-center justify-between mb-1">
                  <span className="pixel-font text-[8px] text-purple-600 uppercase">
                    {item.category}
                  </span>
                  <span className="text-[10px] text-purple-500 font-bold">
                    {item.count} ({item.completed})
                  </span>
                </div>
                <div className="h-2 bg-purple-100 border border-purple-200 overflow-hidden">
                  <div
                    className={`h-full ${getCategoryColor(item.category)}`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Focus */}
      <div className="bg-white p-4 border-4 border-purple-500" style={{ boxShadow: '4px 4px 0 #ff6b9d' }}>
        <h2 className="pixel-font text-xs text-purple-700 mb-4">Daily Focus</h2>
        {dailyFocusData.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-purple-400">
            <Calendar className="h-8 w-8 mb-2 text-purple-300" />
            <p className="pixel-font text-[10px]">No sessions yet!</p>
          </div>
        ) : (
          <div className="flex items-end justify-between gap-1.5 h-24">
            {dailyFocusData.slice(-7).map((day, i) => {
              const maxMinutes = Math.max(...dailyFocusData.map((d) => d.minutes));
              const height = maxMinutes > 0 ? (day.minutes / maxMinutes) * 100 : 0;
              return (
                <div key={i} className="flex flex-col items-center gap-1 flex-1">
                  <div className="w-full bg-purple-100 border border-purple-200 relative h-full">
                    <div
                      className="absolute bottom-0 w-full bg-gradient-to-t from-pink-500 to-purple-500"
                      style={{ height: `${height}%` }}
                    />
                  </div>
                  <span className="pixel-font text-[7px] text-purple-500">{day.label}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function getCategoryColor(category: string): string {
  const colors: Record<string, string> = {
    work: 'bg-blue-500',
    personal: 'bg-pink-500',
    health: 'bg-green-500',
    learning: 'bg-yellow-500',
  };
  return colors[category] || 'bg-gray-500';
}

function getDailyFocusData() {
  return [
    { label: 'Mon', minutes: 45 },
    { label: 'Tue', minutes: 90 },
    { label: 'Wed', minutes: 25 },
    { label: 'Thu', minutes: 120 },
    { label: 'Fri', minutes: 75 },
    { label: 'Sat', minutes: 0 },
    { label: 'Sun', minutes: 50 },
  ];
}
