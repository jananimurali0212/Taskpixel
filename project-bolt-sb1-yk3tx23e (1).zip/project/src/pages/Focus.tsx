import { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Coffee, Target, CheckCircle, Sparkles } from 'lucide-react';
import { supabase, Task, PomodoroSession } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

type TimerMode = 'work' | 'shortBreak' | 'longBreak';

const TIMER_SETTINGS = {
  work: 25,
  shortBreak: 5,
  longBreak: 15,
};

const modeColors: Record<TimerMode, { bg: string; border: string; shadow: string }> = {
  work: { bg: 'bg-pink-500', border: 'border-pink-700', shadow: '#d94a7a' },
  shortBreak: { bg: 'bg-green-500', border: 'border-green-700', shadow: '#16a34a' },
  longBreak: { bg: 'bg-blue-500', border: 'border-blue-700', shadow: '#1d4ed8' },
};

export function Focus() {
  const { user } = useAuth();
  const [mode, setMode] = useState<TimerMode>('work');
  const [timeLeft, setTimeLeft] = useState(TIMER_SETTINGS.work * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [sessionCount, setSessionCount] = useState(0);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (user) {
      fetchTasks();
      fetchTodaySessions();
    }
  }, [user]);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleTimerComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning]);

  const fetchTasks = async () => {
    const { data } = await supabase
      .from('tasks')
      .select('*')
      .eq('completed', false)
      .order('priority', { ascending: false });
    if (data) setTasks(data);
  };

  const fetchTodaySessions = async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const { data } = await supabase
      .from('pomodoro_sessions')
      .select('*')
      .gte('created_at', today.toISOString())
      .not('completed_at', 'is', null);
    if (data) setSessionCount(data.length);
  };

  const startTimer = async () => {
    if (!currentSessionId && mode === 'work') {
      const { data } = await supabase
        .from('pomodoro_sessions')
        .insert({
          user_id: user!.id,
          task_id: selectedTaskId,
          duration_minutes: TIMER_SETTINGS.work,
          started_at: new Date().toISOString(),
        })
        .select()
        .single();
      if (data) setCurrentSessionId(data.id);
    }
    setIsRunning(true);
  };

  const pauseTimer = () => {
    setIsRunning(false);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(TIMER_SETTINGS[mode] * 60);
    if (currentSessionId) {
      supabase.from('pomodoro_sessions').delete().eq('id', currentSessionId);
      setCurrentSessionId(null);
    }
  };

  const handleTimerComplete = async () => {
    setIsRunning(false);
    playNotificationSound();

    if (mode === 'work' && currentSessionId) {
      await supabase
        .from('pomodoro_sessions')
        .update({ completed_at: new Date().toISOString() })
        .eq('id', currentSessionId);
      setCurrentSessionId(null);
      setSessionCount((prev) => prev + 1);
    }

    const nextMode = getNextMode();
    setMode(nextMode);
    setTimeLeft(TIMER_SETTINGS[nextMode] * 60);
  };

  const getNextMode = (): TimerMode => {
    if (mode === 'work') {
      return (sessionCount + 1) % 4 === 0 ? 'longBreak' : 'shortBreak';
    }
    return 'work';
  };

  const switchMode = (newMode: TimerMode) => {
    setIsRunning(false);
    setMode(newMode);
    setTimeLeft(TIMER_SETTINGS[newMode] * 60);
    if (currentSessionId) {
      supabase.from('pomodoro_sessions').delete().eq('id', currentSessionId);
      setCurrentSessionId(null);
    }
  };

  const playNotificationSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      oscillator.frequency.value = 800;
      oscillator.type = 'square';
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
    } catch (e) {
      console.log('Audio not available');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = ((TIMER_SETTINGS[mode] * 60 - timeLeft) / (TIMER_SETTINGS[mode] * 60)) * 100;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4" style={{ background: 'linear-gradient(135deg, #fef3e2 0%, #fff8f0 50%, #ffe4f0 100%)' }}>
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-2">
          <div className="h-8 w-8 bg-pink-500 flex items-center justify-center border-4 border-purple-700" style={{ boxShadow: '4px 4px 0 #a855f7' }}>
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <h1 className="pixel-font text-base text-purple-700">Focus Timer</h1>
        </div>

        {/* Mode Selector */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => switchMode('work')}
            className={`flex-1 px-2 py-2 pixel-font text-[8px] font-bold transition-all flex items-center justify-center gap-1 border-4 ${
              mode === 'work'
                ? `${modeColors.work.bg} text-white ${modeColors.work.border}`
                : 'bg-white text-purple-600 border-purple-400'
            }`}
            style={{ boxShadow: mode === 'work' ? `4px 4px 0 ${modeColors.work.shadow}` : '4px 4px 0 #a855f7' }}
          >
            <Target className="h-4 w-4" />
            FOCUS
          </button>
          <button
            onClick={() => switchMode('shortBreak')}
            className={`flex-1 px-2 py-2 pixel-font text-[8px] font-bold transition-all flex items-center justify-center gap-1 border-4 ${
              mode === 'shortBreak'
                ? `${modeColors.shortBreak.bg} text-white ${modeColors.shortBreak.border}`
                : 'bg-white text-purple-600 border-purple-400'
            }`}
            style={{ boxShadow: mode === 'shortBreak' ? `4px 4px 0 ${modeColors.shortBreak.shadow}` : '4px 4px 0 #a855f7' }}
          >
            <Coffee className="h-4 w-4" />
            SHORT
          </button>
          <button
            onClick={() => switchMode('longBreak')}
            className={`flex-1 px-2 py-2 pixel-font text-[8px] font-bold transition-all flex items-center justify-center gap-1 border-4 ${
              mode === 'longBreak'
                ? `${modeColors.longBreak.bg} text-white ${modeColors.longBreak.border}`
                : 'bg-white text-purple-600 border-purple-400'
            }`}
            style={{ boxShadow: mode === 'longBreak' ? `4px 4px 0 ${modeColors.longBreak.shadow}` : '4px 4px 0 #a855f7' }}
          >
            <Coffee className="h-4 w-4" />
            LONG
          </button>
        </div>

        {/* Timer Display */}
        <div className="bg-white p-6 mb-6 border-4 border-purple-500" style={{ boxShadow: '8px 8px 0 #ff6b9d' }}>
          {/* Progress Bar */}
          <div className="w-full h-3 bg-purple-100 border-2 border-purple-300 mb-4 overflow-hidden">
            <div
              className={`h-full ${modeColors[mode].bg} transition-all duration-1000`}
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="text-center">
            <span className="pixel-font text-4xl text-purple-700 tabular-nums block mb-1">
              {formatTime(timeLeft)}
            </span>
            <span className="pixel-font text-[10px] text-purple-400 uppercase">{mode}</span>
          </div>
        </div>

        {/* Task Selector */}
        {mode === 'work' && (
          <div className="mb-4">
            <label className="block text-[10px] font-bold text-purple-600 mb-1.5 pixel-font">
              Working on (optional)
            </label>
            <select
              value={selectedTaskId || ''}
              onChange={(e) => setSelectedTaskId(e.target.value || null)}
              disabled={isRunning}
              className="w-full px-3 py-2.5 bg-white pixel-input text-sm font-medium text-purple-700 disabled:opacity-50"
            >
              <option value="">Select a task...</option>
              {tasks.map((task) => (
                <option key={task.id} value={task.id}>
                  {task.title}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Controls */}
        <div className="flex gap-3 justify-center mb-6">
          <button
            onClick={resetTimer}
            className="p-3 bg-white border-4 border-purple-400 text-purple-600"
            style={{ boxShadow: '4px 4px 0 #a855f7' }}
          >
            <RotateCcw className="h-5 w-5" />
          </button>
          <button
            onClick={isRunning ? pauseTimer : startTimer}
            className={`flex-1 py-3 pixel-font text-xs border-4 ${
              isRunning
                ? 'bg-yellow-400 text-yellow-900 border-yellow-600'
                : `${modeColors[mode].bg} text-white ${modeColors[mode].border}`
            }`}
            style={{ boxShadow: isRunning ? '4px 4px 0 #ca8a04' : `4px 4px 0 ${modeColors[mode].shadow}` }}
          >
            {isRunning ? (
              <><Pause className="h-5 w-5 inline mr-1" /> PAUSE</>
            ) : (
              <><Play className="h-5 w-5 inline mr-1" /> START</>
            )}
          </button>
        </div>

        {/* Session Count */}
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white border-4 border-purple-400" style={{ boxShadow: '4px 4px 0 #ff6b9d' }}>
            <CheckCircle className="h-4 w-4 text-pink-500" />
            <span className="pixel-font text-[10px] text-purple-700">{sessionCount} TODAY</span>
          </div>
        </div>
      </div>
    </div>
  );
}
